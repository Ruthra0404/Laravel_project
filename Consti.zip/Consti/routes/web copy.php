<?php

use App\Http\Controllers\ConstController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|Route::get('/show_constituencies', [ConstController::class, 'showConstituencies'])->name('show_constituencies');
*/



Route::group(['middleware' => ['preventBackHistory']], function () {
    // Default route
    Route::get('/', function () {
        return view('admin');
    });

    // Authentication routes
    Route::post('/login', [ConstController::class, 'userAuthentication'])->name('login');
    Route::get('/logout', [ConstController::class, 'logout'])->name('logout');

    // Authenticated routes
     Route::middleware('auth')->group(function () {
        // Dashboard route
        Route::get('/home', [ConstController::class, 'showDashboard'])->name('index');

        // Home route
        //  Route::get('/home', [ConstController::class, 'index'])->name('index');
        // Route::get('/home', [ConstController::class, 'showDashboard']);
        // Route::get('/dashboard', [ConstController::class, 'showDashboard']);

        // Other authenticated routes
        Route::get('/create', [ConstController::class, 'create'])->name('create');
        Route::post('/delete-item', [ConstController::class, 'deleteItem'])->name('delete.item');
        Route::post('/storeconstituency', [ConstController::class, 'storeConstituency'])->name('storeconstituency');
        Route::get('/show_constituencies', [ConstController::class, 'showConstituencies'])->name('show_constituencies');
        Route::get('/getConstituencies', [ConstController::class, 'getConstituencies'])->name('getConstituencies');
        Route::post('/storeconstituencyAndShow', [ConstController::class, 'storeAndShow'])->name('storeconstituencyAndShow');
        Route::get('get-item/{id}', [ConstController::class, 'edit'])->name('get.item');
        Route::put('edit-item/{id}', [ConstController::class, 'update'])->name('edit.item');
    });
 });
