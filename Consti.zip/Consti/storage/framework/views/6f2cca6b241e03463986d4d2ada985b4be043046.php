<style>
  li.active a {
    font-weight: bold;
    color: red; /* Customize as needed */
}
 </style>

<nav id="sidebar">
        <!-- Sidebar Header-->
        <div class="sidebar-header d-flex align-items-center">
          <div class="avatar"><i class="bi bi-person" style="font-size: 43px;"></i>
</div>
          <div class="title">
          <?php if(auth()->guard()->check()): ?>
        <?php if((Auth::user()->name != '')): ?>
        
            <h1 class="h5"><?php echo e(Auth::user()->name); ?></h1>
            <!-- <p>Web Designer</p> -->
        <?php else: ?>
        
            <!-- <script>window.location = "<?php echo e(route('/home')); ?>";</script> --> 
            <a href="<?php echo e(route('/home')); ?>"> </a>

        <?php endif; ?>
    <?php endif; ?>
          </div>

        
        </div>
        <!-- Sidebar Navidation Menus-->
        <span class="heading">Main</span>
<ul class="list-unstyled">
    <li class="<?php echo e(request()->routeIs('index') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('index')); ?>"> <i class="icon-home"></i>Home </a>
    </li>
    <li class="<?php echo e(request()->routeIs('create') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('create')); ?>"> <i class="bi bi-plus-circle"></i> Create </a>
    </li>
    <li class="<?php echo e(request()->routeIs('show_constituencies') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('show_constituencies')); ?>"> <i class="icon-grid"></i>List </a>
    </li>
</ul>

             
               
      </nav><?php /**PATH /opt/lampp/htdocs/Consti/resources/views/admin/sidebar.blade.php ENDPATH**/ ?>