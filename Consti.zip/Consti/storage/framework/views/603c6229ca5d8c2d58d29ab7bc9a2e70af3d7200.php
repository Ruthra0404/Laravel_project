<!DOCTYPE html>
<html>
  <head> 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Constituency </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
   <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>
  <body>
  <form method="post" action="<?php echo e(route('login')); ?>">
   <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="d-flex align-items-stretch">
      <!-- Sidebar Navigation-->
      <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
      <!-- Sidebar Navigation end-->
      <div class="page-content">
        <div class="page-header">
          <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">Dashboard</h2>
          </div>
        </div>
        <section class="no-padding-top no-padding-bottom">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="statistic-block block">
                        <div class="progress-details d-flex align-items-end justify-content-between">
                            <div class="title">
                                <div class="icon"><i class="icon-user-1"></i></div>
                                <strong>Total Constituencies</strong>
                            </div>
                            <div class="number dashtext-1"><?php echo e($data->total_constituencies ?? 'N/A'); ?></div>
                        </div>
                        <div class="progress progress-template">
                            <div role="progressbar" style="width: 30%" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" class="progress-bar progress-bar-template dashbg-1"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="statistic-block block">
                        <div class="progress-details d-flex align-items-end justify-content-between">
                            <div class="title">
                                <div class="icon"><i class="icon-contract"></i></div>
                                <strong>Today Constituencies</strong>
                            </div>
                            <div class="number dashtext-2"><?php echo e($data->today_constituencies ?? 'N/A'); ?></div>
                        </div>
                        <div class="progress progress-template">
                            <div role="progressbar" style="width: 70%" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" class="progress-bar progress-bar-template dashbg-2"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="statistic-block block">
                        <div class="progress-details d-flex align-items-end justify-content-between">
                            <div class="title">
                                <div class="icon"><i class="icon-paper-and-pencil"></i></div>
                                <strong>One-week Constituencies</strong>
                            </div>
                            <div class="number dashtext-3"><?php echo e($data->last_week_constituencies ?? 'N/A'); ?></div>
                        </div>
                        <div class="progress progress-template">
                            <div role="progressbar" style="width: 55%" aria-valuenow="55" aria-valuemin="0" aria-valuemax="100" class="progress-bar progress-bar-template dashbg-3"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="statistic-block block">
                        <div class="progress-details d-flex align-items-end justify-content-between">
                            <div class="title">
                                <div class="icon"><i class="icon-writing-whiteboard"></i></div>
                                <strong>One-month Constituencies</strong>
                            </div>
                            <div class="number dashtext-4"><?php echo e($data->last_month_constituencies ?? 'N/A'); ?></div>
                        </div>
                        <div class="progress progress-template">
                            <div role="progressbar" style="width: 35%" aria-valuenow="35" aria-valuemin="0" aria-valuemax="100" class="progress-bar progress-bar-template dashbg-4"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="no-padding-bottom">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-4">
                    <div class="bar-chart block no-margin-bottom">
                        <canvas id="barChart_1"></canvas>
                    </div>
                    <div class="bar-chart block">
                        <canvas id="barChart_2"></canvas>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="line-chart block">
                        <canvas id="lineChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </section>
       
</form>
        <!-- <footer class="footer">
          <div class="footer__block block no-margin-bottom">
            <div class="container-fluid text-center"> -->
              <!-- Please do not remove the backlink to us unless you support us at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
               <!-- <p class="no-margin-bottom">2018 &copy; Your company. Download From <a target="_blank" href="https://templateshub.net">Templates Hub</a>.</p>
            </div>
          </div>
        </footer> -->
      </div>
    </div>
    <!-- JavaScript files-->
    <script src="admin/vendor/jquery/jquery.min.js"></script>
    <script src="admin/vendor/popper.js/umd/popper.min.js"> </script>
    <script src="admin/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="admin/vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="admin/vendor/chart.js/Chart.min.js"></script>
    <script src="admin/vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="admin/js/charts-home.js"></script>
    <script src="admin/js/front.js"></script>
    <script>
    $(document).ready(function () {
        // Chart data
        const chartData = {
            labels: ['Total', 'Today', 'Last Week', 'Last Month'],
            datasets: [{
                label: 'Constituencies',
                data: [
                    <?php echo e($data->total_constituencies ?? 0); ?>,
                    <?php echo e($data->today_constituencies ?? 0); ?>,
                    <?php echo e($data->last_week_constituencies ?? 0); ?>,
                    <?php echo e($data->last_month_constituencies ?? 0); ?>

                ],
                backgroundColor: [
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(153, 102, 255, 0.2)'
                ],
                borderColor: [
                    'rgba(75, 192, 192, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(153, 102, 255, 1)'
                ],
                borderWidth: 1
            }]
        };

        // Bar Chart Example 1
        const ctx1 = document.getElementById('barChart_1').getContext('2d');
        new Chart(ctx1, {
            type: 'bar',
            data: chartData,
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                },
                plugins: {
                    tooltip: {
                        enabled: false // Disable tooltips
                    },
                    legend: {
                        display: false // Disable legend if needed
                    }
                },
                hover: {
                    mode: null // Disable hover effects
                }
            }
        });

        // Bar Chart Example 2
        // const ctx2 = document.getElementById('barChart_2').getContext('2d');
        // new Chart(ctx2, {
        //     type: 'bar',
        //     data: chartData,
        //     options: {
        //         scales: {
        //             y: {
        //                 beginAtZero: true
        //             }
        //         },
        //         plugins: {
        //             tooltip: {
        //                 enabled: false // Disable tooltips
        //             },
        //             legend: {
        //                 display: false // Disable legend if needed
        //             }
        //         },
        //         hover: {
        //             mode: null // Disable hover effects
        //         }
        //     }
        // });

        // Line Chart
        const ctx3 = document.getElementById('lineChart').getContext('2d');
        new Chart(ctx3, {
            type: 'line',
            data: chartData,
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                },
                plugins: {
                    tooltip: {
                        enabled: false // Disable tooltips
                    },
                    legend: {
                        display: false // Disable legend if needed
                    }
                },
                hover: {
                    mode: null // Disable hover effects
                }
            }
        });
    });
</script>
<script>
    $(document).ready(function () {
        // Chart data for barChart_2
        const barChart2Data = {
            labels: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'], // X-axis labels for days
            datasets: [{
                label: 'Constituencies',
                data: [
                    // Replace these values with the actual constituency counts for each day
                    10, // Monday
                    20, // Tuesday
                    15, // Wednesday
                    25, // Thursday
                    30  // Friday
                ],
                backgroundColor: [
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)'
                ],
                borderColor: [
                    'rgba(75, 192, 192, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            }]
        };

        // Bar Chart Example 2
        const ctx2 = document.getElementById('barChart_2').getContext('2d');
        new Chart(ctx2, {
            type: 'bar',
            data: barChart2Data, // Use the customized data for barChart_2
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Constituency Count' // Y-axis label
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Day' // X-axis label
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        enabled: false // Disable tooltips
                    },
                    legend: {
                        display: false // Disable legend if needed
                    }
                },
                hover: {
                    mode: null // Disable hover effects
                }
            }
        });
    });
</script>



  </body>
</html><?php /**PATH /opt/lampp/htdocs/Consti/resources/views/home.blade.php ENDPATH**/ ?>