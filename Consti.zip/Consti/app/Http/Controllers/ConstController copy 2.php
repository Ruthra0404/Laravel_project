<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Constituency;
use App\Models\Language;
use App\Models\User;
use Illuminate\Support\Str;
use Yajra\DataTables\Facades\DataTables;
use App\Models\StoreConstituency;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Log;
use DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
class ConstController extends Controller
{
    public function create()
    {
        $constituencies = Constituency::all();
        $languages = Language::all();
        return view('layouts.index', compact('constituencies', 'languages'));
    }

    // public function store(Request $request)
    // {
    //     // Retrieve constituencies from the request (assuming you want to process and save these later)
    //     $constituencies = $request->input('constituency', []);

    //     return view('layouts.list', compact('constituencies'));
    // }

    // public function getDescription(Request $request)
    // {
    //     $constituencyId = $request->input('constituencyId');
    //     $constituency = Constituency::find($constituencyId);

    //     // Check if the constituency exists
    //     if (!$constituency) {
    //         return response()->json(['error' => 'Constituency not found'], 404);
    //     }

    //     // Return the required attributes as JSON
    //     return response()->json([
    //         'description' => $constituency->description,
    //         'link' => $constituency->link,
    //     ]);
    // }

    public function getLanguage(Request $request)
    {
        $languageId = $request->input('languageId');
        $language = Language::find($languageId);

        // Check if the language exists
        if (!$language) {
            return response()->json(['error' => 'Language not found'], 404);
        }

        // Return the required attributes as JSON
        return response()->json([
            'name' => $language->name,
            'code' => $language->code,
            'status' => $language->status,
        ]);
    }

public function storeConstituency(Request $request)
{
    try {
      
        // Validate the form data
        // $request->validate([
        //     'constituency' => 'required|array',
        //     'language' => 'required|exists:languages,id',
        //     'message' => 'required|string',
        //     'link' => 'required|url',
           
           
        // ]);
        
        // Get the form inputs
        $languageId = $request->input('language_id');
        $description = $request->input('message');
        $link = $request->input('link');
        $status = 'Y';
        $createdAt = now();
        $updatedAt = now();
     
       
        // Prepare the base data for insertion
        $baseData = [
            'language_id' => $languageId,
            'description' => $description,
            'link' => $link,
            'status' => $status,
            'created_at' => $createdAt,
            'updated_at' => $updatedAt
        ];
      
        // Get the array of constituency IDs
        $constituencyIds = $request->input('constituency');
        // Iterate over each constituency ID and insert a record for each
        foreach ($constituencyIds as $constituencyId) {
            $storedata = array_merge($baseData, ['constituency_id' => $constituencyId]);
            DB::table('store_constituency')->insert($storedata);
        }
      

        // Redirect back with a success message
        return redirect()->route('show_constituencies')->with('success', 'Data submitted successfully!');
    } catch (\Exception $e) {
        // Log the error
        Log::error('Error storing constituency: ' . $e->getMessage());

        // Redirect back with an error message
        return Redirect::back()->with('error', 'An error occurred while storing the data.');
    }
}
public function showConstituencies()
{
    // Your logic to retrieve or process constituencies
    $constituencies = StoreConstituency::all(); // Example
 

    return view('layouts.show_constituencies', compact('constituencies'));
     // Pass data to the view
}

public function getConstituencies(Request $request)
{
    if ($request->ajax()) {
        $data = DB::table('store_constituency')
            ->select(
                'store_constituency.description', 
                'store_constituency.link',
                'store_constituency.created_at', 
                'store_constituency.status', 
                'languages.name as language_name', 
                'master_constituency.constituency'
            )
            ->join('master_constituency', 'store_constituency.constituency_id', '=', 'master_constituency.id')
            ->join('languages', 'store_constituency.language_id', '=', 'languages.id');

        return DataTables::of($data)
            ->addIndexColumn()
            ->addColumn('action', function ($row) {
                $btn = '<a href="javascript:void(0)" class="edit btn btn-primary btn-sm">Edit</a>';
                $btn .= ' <a href="javascript:void(0)" class="delete btn btn-danger btn-sm" id=>Delete</a>';
                return $btn;
            })
            ->filterColumn('constituency', function($query, $keyword) {
                $query->whereRaw("master_constituency.constituency like ?", ["%{$keyword}%"]);
            })
            ->filterColumn('language_name', function($query, $keyword) {
                $query->whereRaw("languages.name like ?", ["%{$keyword}%"]);
            })
            ->filterColumn('description', function($query, $keyword) {
                $query->whereRaw("store_constituency.description like ?", ["%{$keyword}%"]);
            })
            ->filterColumn('link', function($query, $keyword) {
                $query->whereRaw("store_constituency.link like ?", ["%{$keyword}%"]);
            })
            ->filterColumn('status', function($query, $keyword) {
                $query->whereRaw("store_constituency.status like ?", ["%{$keyword}%"]);
            })
            ->filterColumn('created_at', function($query, $keyword) {
                $query->whereRaw("store_constituency.created_at like ?", ["%{$keyword}%"]);
            })
            ->rawColumns(['action'])
            ->make(true);
    }

    return view('show_constituencies');
}
// public function login(Request $request)
// {
//     // Validate the input
//     $request->validate([
//         'username' => 'required',
//         'password' => 'required',
//     ]);

//     // Find the user by username
//     $user = User::where('username', $request->input('username'))->first();

//     // Check if user exists and if the password is correct
//     if ($user && Hash::check($request->input('password'), $user->password)) {
//         // Log the user in
//         Auth::login($user);
//         return redirect()->route('layouts.index');
//     } else {
//         // Return back with error message
//         return back()->with('error', 'Incorrect username or password');
//     }
// }
public function deleteConstituency($id, Request $request)
{
    $constituency = DB::table('store_constituency')
        ->where('id', $id)
        ->update(['status' => 'D']);

    return response()->json(['message' => 'Constituency deleted successfully']);
}
public function login(Request $request)
    {
        $request->validate([
            'username' => 'required',
            'password' => 'required',
        ]);

        $user = User::where('username', $request->username)->first();

        if ($user && Hash::check($request->password, $user->password)) {
            Auth::login($user);
            return redirect()->intended('layouts.index'); // Change to the intended route after login
        } else {
            return redirect()->back()->with('error', 'Incorrect username or password');
        }

}











// public function storeAndShow(Request $request)
// {
//     // Process form submission here

//     return redirect()->route('show_constituencies');
// }

}
