<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Constituency;
use App\Models\Language;
use App\Models\User;
use Illuminate\Support\Str;
use Yajra\DataTables\Facades\DataTables;
use App\Models\StoreConstituency;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Log;
use DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use App\Models\UserLog;

class ConstController extends Controller
{
    public function index()
    {
       
        return view('home');
    }

    public function create()
    {
        $constituencies = Constituency::all();
        $languages = Language::all();
        return view('layouts.create', compact('constituencies', 'languages'));
    }


    public function getLanguage(Request $request)
    {
        $languageId = $request->input('languageId');
        $language = Language::find($languageId);

        // Check if the language exists
        if (!$language) {
            return response()->json(['error' => 'Language not found'], 404);
        }

        // Return the required attributes as JSON
        return response()->json([
            'name' => $language->name,
            'code' => $language->code,
            'status' => $language->status,
        ]);
    }

    public function storeConstituency(Request $request)
    {
        try {
            // Validate the form data
            $request->validate([
                'constituency' => 'required',
                'language_id' => 'required|exists:languages,id',
                'message' => 'required|string',
                'link' => 'nullable|url',  // 'link' is optional
            ]);
    
            // Get the form inputs
            $languageId = $request->input('language_id');
            $description = $request->input('message');
            $link = $request->input('link', '');  // Default to an empty string if link is null
            $status = 'Y';
            $createdAt = now();
            $updatedAt = now();
    
            // Prepare the base data for insertion
            $baseData = [
                'language_id' => $languageId,
                'description' => $description,
                'link' => $link,
                'status' => $status,
                'created_at' => $createdAt,
                'updated_at' => $updatedAt,
            ];
   
            // Get the array of constituency IDs
            $constituencyIds = $request->input('constituency');
            
            // Begin a transaction
            DB::beginTransaction();
    
            try {
                // Iterate over each constituency ID and insert a record for each
                foreach ($constituencyIds as $constituencyId) {
                    $storeData = array_merge($baseData, ['constituency_id' => $constituencyId]);
                    DB::table('store_constituency')->insert($storeData);
                }
    
                // Commit the transaction
                DB::commit();
            } catch (\Exception $e) {
                // Rollback the transaction if something goes wrong
                DB::rollBack();
                throw $e;  // Re-throw the exception to be caught by the outer try-catch
            }
    
            // Redirect back with a success message
            return redirect()->route('show_constituencies')->with('success', 'Data submitted successfully!');
        } catch (\Exception $e) {
            // Log the error
            Log::error('Error storing constituency: ' . $e->getMessage());
    
            // Redirect back with an error message
            return Redirect::back()->with('error', 'An error occurred while storing the data.');
        }
    }
    public function userAuthentication(Request $request)
    {
        dd('hello4');


        $request->validate([
            'username' => 'required|string',
            'password' => 'required|string',
        ]);
        $credentials = [
            'name' => $request->input('username'),
            'password' => $request->input('password'),
        ];
       

        // if (Auth::attempt($credentials)) {
        //     Log::info('Authentication successful');
        //     return redirect()->route('index');
        // } else {
        //     Log::error('Invalid credentials');
        //     return redirect()->back()->withErrors(['auth_error' => 'Invalid username or password']);
        // }
        if (Auth::attempt($credentials)) 
				{

					$user = Auth::user();

					if ($user->user_status === 'I') 
					{
							// Authentication passed, retrieve the user
							$userId = $user->id;
							$ip_address = $request->ip();

							// Execute the stored procedure
							$query = DB::select('CALL login(?, ?)', 
							[
									$userId,
									$ip_address,
							]);

							// Check if the procedure returned a message
							if ($query && isset($query[0]->response_msg)) 
							{
			
								// Check the message for success or failure
								if ($query[0]->response_msg === 'success') 
								{
										// Log::channel('log_data')->info('user log query response: ' . $query[0]->response_msg);

										// Success message
										// Store the login_time in the session
										$request->session()->put('login_time', now());
			
										// Store the user ID in the session
										$request->session()->put('user_id', $user->id);

										// Redirect to the user's dashboard or another page
										return redirect('/home');
								} 
								else 
								{
										// Log::channel('log_data')->info('user log query error response: ' . $query[0]->response_msg);

								}
							} 
							else 
							{

										// Log::channel('log_data')->info('user log query error response: ' . json_encode($query));

							}
					} 
					else 
					{
						Auth::logout();
            // User status is 'N' - Inactive user
						return view('\login')->withErrors(['login' => 'Inactive or Not Approved User. Kindly contact your admin!']);

        	}

						
				}
 
  			// Authentication failed, redirect back with errors
              return redirect()->back()->withErrors(['auth_error' => 'Invalid username or password']);

    }
    
public function showConstituencies()
{
    // Your logic to retrieve or process constituencies
    $constituencies = Constituency::all(); // Example
    $languages = Language::all();
 

    return view('layouts.show_constituencies', compact('constituencies','languages'));
     // Pass data to the view
}

public function getConstituencies(Request $request)
{
    if ($request->ajax()) {
        $data = DB::table('store_constituency')
            ->select(
                'store_constituency.id',
                'store_constituency.description', 
                'store_constituency.link',
                'store_constituency.created_at', 
                'store_constituency.status', 
                'languages.name as language_name', 
                'master_constituency.constituency'
            )
            ->join('master_constituency', 'store_constituency.constituency_id', '=', 'master_constituency.id')
            ->join('languages', 'store_constituency.language_id', '=', 'languages.id');

        return DataTables::of($data)
            ->addIndexColumn()
            ->addColumn('action', function ($row) {
                $btn = '<a href="javascript:void(0)" class="edit btn btn-primary btn-sm" data-id="' . $row->id . '">Edit</a>';
                if ($row->status == 'D') {
                    $btn .= ' <a href="javascript:void(0)" class="delete btn btn-danger btn-sm" data-id="' . $row->id . '" disabled style="pointer-events: none;">Delete</a>';
                } else {
                    $btn .= ' <a href="javascript:void(0)" class="delete btn btn-danger btn-sm" data-id="' . $row->id . '">Delete</a>';
                }
                
                
                return $btn;
            }
            )
            ->filterColumn('constituency', function($query, $keyword) {
                $query->whereRaw("master_constituency.constituency like ?", ["%{$keyword}%"]);
            })
            ->filterColumn('language_name', function($query, $keyword) {
                $query->whereRaw("languages.name like ?", ["%{$keyword}%"]);
            })
            ->filterColumn('description', function($query, $keyword) {
                $query->whereRaw("store_constituency.description like ?", ["%{$keyword}%"]);
            })
            ->filterColumn('link', function($query, $keyword) {
                $query->whereRaw("store_constituency.link like ?", ["%{$keyword}%"]);
            })
            ->filterColumn('status', function($query, $keyword) {
                $query->whereRaw("store_constituency.status like ?", ["%{$keyword}%"]);
            })
            ->filterColumn('created_at', function($query, $keyword) {
                $query->whereRaw("store_constituency.created_at like ?", ["%{$keyword}%"]);
            })
            ->rawColumns(['action'])
            ->make(true);
    }

    return view('show_constituencies');
}

public function deleteItem(Request $request)
{
    $id = $request->input('id');
    $item = DB::table('store_constituency')->where('id', $id)->first();
    
    if ($item) {
        DB::table('store_constituency')->where('id', $id)->update(['status' => 'D']);
        return response()->json(['success' => true]);
    } else {
        return response()->json(['success' => false]);
    }
}

/*public function userAuthentication(Request $request)
{
    // dd('welcome');
    // Validate the incoming request
    $request->validate([
        'username' => 'required|string',
        'password' => 'required|string',
    ]);

    // Get the input values from the request
    $username = $request->input('username');
    $password = $request->input('password');

    // Log the input values for debugging
    \Log::info('Attempting authentication with:', ['username' => $username]);

    // Construct credentials array
    $credentials = [
        'name' => $username,
        'password' => $password,
    ];

    // Attempt authentication
    if (Auth::attempt($credentials)) {
        \Log::info('Authentication successful');
        return redirect()->route('home');
    } else {
        // Check if user exists
        $user = User::where('name', $username)->first();
        if ($user) {
            // Check if password matches
            if (Hash::check($password, $user->password)) {
                \Log::error('Password matches but authentication still fails. Check guards and settings.');
            } else {
                \Log::error('Password does not match for user:', ['username' => $username]);
            }
        } else {
            \Log::error('User does not exist:', ['username' => $username]);
        }

        return redirect()->back()->withInput($request->only('username'))->withErrors([
            'auth_error' => 'Invalid username or password',
        ]);
    }
}*/




// Method to fetch item details 

public function edit($id)
{
    $storeConstituency = StoreConstituency::findOrFail($id);
    $masterConstituency = Constituency::findOrFail($storeConstituency->constituency_id);
    $language = Language::findOrFail($storeConstituency->language_id);

    return response()->json([
        'id' => $storeConstituency->id,
        'constituency_id' => $masterConstituency->id, // Include the ID of the selected constituency
        'language_id' => $language->id, // Include the ID of the selected language
        'description' => $storeConstituency->description,
        'link' => $storeConstituency->link,
        'status' => $storeConstituency->status,
    ]);
}


    public function update(Request $request, $id)
    {
        $request->validate([
            'description' => 'required',
            'link' => 'nullable|url',
            'constituency' => 'required',
            'language_name' => 'required',
        ]);
    
        DB::transaction(function () use ($request, $id) {
            $storeConstituency = StoreConstituency::findOrFail($id);
            $storeConstituency->description = $request->input('description');
            $storeConstituency->link = $request->input('link');
            $storeConstituency->constituency_id = $request->input('constituency');
            $storeConstituency->language_id = $request->input('language_name');
            $storeConstituency->save();
        });
    
        return response()->json(['success' => 'Record updated successfully.']);
    }
    
    
    // public function showDashboard()
    // {
    //     $data = DB::table('store_constituency')
    //         ->selectRaw('
    //             COUNT(*) AS total_constituencies,
    //             SUM(DATE(created_at) = CURDATE()) AS today_constituencies,
    //             SUM(created_at >= CURDATE() - INTERVAL 7 DAY) AS last_week_constituencies,
    //             SUM(created_at >= CURDATE() - INTERVAL 1 MONTH) AS last_month_constituencies
    //         ')
    //         ->first();
    //  $monday_to_friday_data = [];
    // for ($i = 0; $i < 5; $i++) {
    //     $date = now()->startOfWeek()->addDays($i);
    //     $constituency_count = StoreConstituency::whereDate('created_at', $date)->count();
    //     $monday_to_friday_data[$date->format('D')] = $constituency_count;
    // }

    //     return view('home', ['data' => $data]);  // Make sure your view name is correct
    // }
    public function showDashboard()
    {
        $data = DB::table('store_constituency')
            ->selectRaw('
                COUNT(*) AS total_constituencies,
                SUM(DATE(created_at) = CURDATE()) AS today_constituencies,
                SUM(created_at >= CURDATE() - INTERVAL 7 DAY) AS last_week_constituencies,
                SUM(created_at >= CURDATE() - INTERVAL 1 MONTH) AS last_month_constituencies
            ')
            ->first();

        $monday_to_friday_data = [];
        for ($i = 0; $i < 5; $i++) {
            $date = now()->startOfWeek()->addDays($i);
            $constituency_count = DB::table('store_constituency')->whereDate('created_at', $date)->count();
            $monday_to_friday_data[$date->format('D')] = $constituency_count;
        }

        return view('home', [
            'data' => $data,
            'monday_to_friday_data' => $monday_to_friday_data
        ]);
        // return view('home');
    }
    
    // public function logout(){
    //     dd('hello');
    //     Session::flush();
    //     Auth::guard($this->getGuard())->logout();
    //     return redirect(property_exists($this, 'redirectAfterLogout') ? $this->redirectAfterLogout : '/');
    // }
    public function logout(Request $request)
    {
        // Update the user log entry with logout time and status
        $userLog = UserLog::where('user_id', Auth::user()->id)
            ->where('user_log_status', 'I')
            ->orderBy('login_time', 'desc')
            ->first();
    
        if ($userLog) {
            $userLog->update([
                'logout_time' => now(),
                'user_log_status' => 'O', // Assuming 'O' represents logout status.
            ]);
        }
    
        // Flush the session data
        $request->session()->flush();
    
        // Perform the logout
        Auth::logout();
    
        return redirect('/');
    }

    }
   