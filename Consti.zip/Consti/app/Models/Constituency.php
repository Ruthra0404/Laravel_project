<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Constituency extends Model
{
    // use HasFactory, SoftDeletes; (Optional)

    protected $fillable = [
        'id',
        'constituency', // Assuming 'constituency' column stores the constituency name
        'timestamp',
       
    ];

    protected $table = 'master_constituency'; // Explicitly define the table name
}
