<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class StoreConstituency extends Model
{
	protected $table = 'store_constituency';
	protected $fillable = [
		    'id',
        'constituency_id',
        'language_id',
        'description',
        'link',
				'created_at',
				'updated_at',
        'status',
    ];
	
	
}