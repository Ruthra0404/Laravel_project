const gulp = require('gulp');

// Define your build tasks here...

gulp.task('default', function() {
    // Your default build tasks (optional)
});
