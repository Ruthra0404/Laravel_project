<script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js" defer></script>
<style>
    .pb-3,
    .py-3 {
        padding-bottom: 0.5rem !important;
    }

    .pt-3,
    .py-3 {
        padding-top: 0.5rem !important;
    }

    .static-badge {
        display: inline-block;
        width: 30px;
        /* Set the width */
        height: 30px;
        /* Set the height */
        line-height: 30px;
        /* Center the text vertically */
        text-align: center;
        /* Center the text horizontally */
        border-radius: 50%;
        /* Make it round */
        /* background-color: whitesmoke; Set the background color */
        color: black;
        /* Set the text color */
    }
</style>
{{-- #303c5a --}}

<aside class="w-full md:w-64 bg-gray-800 md:min-h-screen menu_list" x-data="{ isOpen: false }"
    :class="{ 'md:block': isOpen, 'md:hidden': !isOpen }">
    <!-- Header -->
    <div class="flex items-center justify-between bg-white p-4 h-16" style="background-color: #fff !important;">
        <!-- <a href="{{ route('index') }}" class="flex items-center">
            <img src="https://yourpostman.in/accounting_portal/public/css/celebmedia_logo.png" alt="logo"
                class="logo" style ="width: 167px;height: 65px;">
        </a> -->
    </div>

    <!-- Sidebar Navigation -->
    <div class="px-2 py-6 md:block " :class="isOpen ? 'block' : 'hidden'" style="width: 255px;" id= "content">
        <ul>

            <!-- index page redirect -->
            <li class="px-2 py-3 hover:bg-red-900 {{ Request()->is('index') ? 'in_active' : '' }} rounded-lg index">
                <a href={{ route('index') }} class="flex items-center">
                    <svg class="w-6 {{ Request()->is('index') ? 'text-white' : 'text-black' }} {{ Request()->is('index') ? 'in_active' : '' }} "
                        fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        viewBox="0 0 24 24" stroke="currentColor">
                        <path
                            d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6">
                        </path>
                    </svg>
                    <span
                        class="mx-2 {{ Request()->is('index') ? 'text-white' : 'text-black' }} {{ Request()->is('index') ? 'in_active' : '' }} text-xl font-bold ">Dashboard</span>
                </a>
            </li>
            <li
                class="px-2 py-3 hover:bg-red-900 {{ request()->is('create') ? 'in_active' : '' }} rounded mt-2 create">
                <a href="{{ route('create') }}" class="flex items-center">
                    <svg class="h-8 w-8 {{ Request()->is('create') ? 'text-white' : 'text-black' }} {{ Request()->is('create') ? 'in_active' : '' }}"
                        width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"
                        fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" />
                        <path d="M14 3v4a1 1 0 0 0 1 1h4" />
                        <path d="M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2z" />
                        <circle cx="11" cy="16" r="1" />
                        <polyline points="12 16 12 11 14 12" />
                    </svg>
                    <span
                        class="mx-2 {{ Request()->is('create') ? 'text-white' : 'text-black' }} {{ Request()->is('create') ? 'in_active' : '' }} text-xl font-bold">create
                        </span>
                </a>

            </li>


            <!-- Credit Management page redirect -->

           
            <!-- Context create page redirect -->

            <li
                class="px-2 py-3 hover:bg-red-900 {{ request()->is('show_constituencies') ? 'in_active' : '' }} rounded mt-2 show_constituencies">
                <a href="{{ route('show_constituencies') }}" class="flex items-center">
                    <svg class="h-8 w-8 {{ Request()->is('show_constituencies') ? 'text-white' : 'text-black' }} {{ Request()->is('show_constituencies') ? 'in_active' : '' }}"
                        width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"
                        fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" />
                        <path d="M14 3v4a1 1 0 0 0 1 1h4" />
                        <path d="M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2z" />
                        <circle cx="11" cy="16" r="1" />
                        <polyline points="12 16 12 11 14 12" />
                    </svg>
                    <span
                        class="mx-2 {{ Request()->is('show_constituencies') ? 'text-white' : 'text-black' }} {{ Request()->is('show_constituencies') ? 'in_active' : '' }} text-xl font-bold">Show
                        List</span>
                </a>

            </li>



           

        </ul>
    </div>
</aside>
