<!DOCTYPE html>
<html>
  <head> 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Constituency </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.7.1/css/buttons.dataTables.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="../css/multi-checkbox-select.css">
<link rel="stylesheet" href="../css/select2.min.css">

<meta name="csrf-token" content="{{ csrf_token() }}">
   @include('admin.css')
   <style>
    select { width: 100%; }
    .required-field::after {
    content: ' *';
    color: red;
}
table.dataTable tbody tr {
    background-color: #282b2f !important;
    color:white !important;
}
.table-striped>tbody>tr:nth-of-type(odd) {
    --bs-table-accent-bg: var(--bs-table-striped-bg);
    color:black;
}
.table {
    width: 100%;
    margin-bottom: 1rem;
    color: black;
    hover: none; /* Uncomment this line to remove hover effect */
}

button.dt-button, div.dt-button, a.dt-button, input.dt-button{
    color: black;
}
.dataTables_wrapper .dataTables_length, .dataTables_wrapper .dataTables_filter, .dataTables_wrapper .dataTables_info, .dataTables_wrapper .dataTables_processing, .dataTables_wrapper .dataTables_paginate {
    color:black;
}
.dataTables_wrapper .dataTables_paginate .paginate_button.disabled, .dataTables_wrapper .dataTables_paginate .paginate_button.disabled:hover, .dataTables_wrapper .dataTables_paginate .paginate_button.disabled:active {
    cursor: default;
    color: black !important;
    border: 1px solid transparent;
    background: transparent;
    box-shadow: none;
}
table.dataTable tbody th, table.dataTable tbody td {
    padding: 8px 10px;
    color: black !important;
}
.table-striped tbody tr:nth-of-type(odd) {
    background-color: white !important;
}
.table-striped tbody tr:nth-of-type(even) {
    background-color: white !important;
}
.dt-buttons{
    color:blue;
}
</style>
  </head>
  <body>
  <form method="post" action="{{ route('login') }}">
   @include('admin.header')
   @if(session('success'))
   <div class="alert alert-success alert-dismissible" id="successMessage" role="alert">
        <strong>{{ session('success') }}</strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            <span class="sr-only">Close</span>
        </button>
    </div>
@endif
    <div class="d-flex align-items-stretch">
      <!-- Sidebar Navigation-->
      @include('admin.sidebar') 
      <!-- Sidebar Navigation end-->
      <div class="page-content">
        <div class="page-header">
          <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">List Page</h2>
          </div>
        </div>
        <div class="container mt-5">
    <h2 class="text-center">Constituencies</h2>
    <div class="row justify-content-center">
        <div class="container-fluid d-flex align-items-center justify-content-between">
            <table id="constituency-datatable" class="table table-striped table-bordered table-hover">
                <thead>
                    <tr>
                        <th>S.No</th>
                        <th>Constituency</th>
                        <th>Language</th>
                        <th>Description</th>
                        <th>Link</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
</div>


<!-- Edit Modal -->
<div id="editModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form id="editForm">
                <input type="hidden" id="edit-id" name="id">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="constituency" class="form-label required-field" style="color:black">Constituency</label>
                        <select name="constituency" id="constituency" class="form-control">
                            @foreach($constituencies as $constituency)
                                <option value="{{ $constituency->id }}">{{ $constituency->constituency }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="language_name" class="form-label required-field">Language Name</label>
                        <select id="language_name" name="language_name" class="form-control">
                            @foreach($languages as $language)
                                <option value="{{ $language->id }}">{{ $language->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="description" class="form-label required-field">Description</label>
                        <input type="text" id="description" name="description" onkeypress="return /^[0-9a-zA-Z\s]*$/i.test(event.key)" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="link">Link</label>
                        <input type="text" id="link" name="link" class="form-control">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" id="closeBtn">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

       
</form>
        
      </div>
    </div>
    <!-- JavaScript files-->
    <script src="admin/vendor/jquery/jquery.min.js"></script>
    <script src="admin/vendor/popper.js/umd/popper.min.js"> </script>
    <script src="admin/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="admin/vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="admin/vendor/chart.js/Chart.min.js"></script>
    <script src="admin/vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="admin/js/charts-home.js"></script>
    <script src="admin/js/front.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/multiple-select/1.5.2/multiple-select.min.js"></script> -->
<script src="../js/multiselect-dropdown.js"></script>
<script src="../js/multi-checkbox-select.js"></script>

<script type="text/javascript">
$(document).ready(function() {
   

    var table = $('#constituency-datatable').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: "{{ route('getConstituencies') }}",
        },
        columns: [
            { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false },
            { data: 'constituency', name: 'constituency' },
            { data: 'language_name', name: 'language_name' },
            { data: 'description', name: 'description' },
            { data: 'link', name: 'link' },
            {
                data: 'status',
                name: 'status',
                render: function(data, type, row) {
                    if (data == 'Y') {
                        return '<span style="color: green;">' + 'Active' + '</span>';
                    } else if (data == 'D') {
                        return '<span style="color: red;">' + 'Inactive' + '</span>';
                    } else {
                        return data;
                    }
                }
            },
            { data: 'created_at', name: 'created_at' },
            { data: 'action', name: 'action', orderable: false, searchable: false },
        ],
        dom: 'Bfrtip',
        buttons: [
            { extend: 'csv', text: 'CSV', className: 'btn-custom-primary' },
            { extend: 'pdf', text: 'PDF', className: 'btn-custom-success' },
            { extend: 'print', text: 'Print', className: 'btn-custom-info' }
        ],
        order: [[6, 'desc']],
        drawCallback: function(settings) {
            var api = this.api();
            var rows = api.rows({ page: 'current' }).nodes();
            var lastRow = null;
            
            // Find the last saved row
            rows.each(function(index) {
                var row = api.row(index).node();
                if (!lastRow) {
                    lastRow = row;
                } else {
                    var lastCreatedAt = $(lastRow).find('td:eq(6)').text(); // 6 is the index of the 'created_at' column
                    var currentCreatedAt = $(row).find('td:eq(6)').text(); // 6 is the index of the 'created_at' column
                    if (currentCreatedAt > lastCreatedAt) {
                        lastRow = row;
                    }
                }
            });
            
            // Move the last saved row to the top
            $(lastRow).insertBefore(rows[0]);
        }
    });

    // Event listener for toggling sorting order for S.No column
    $('#constituency-datatable thead th:first-child').on('click', function() {
        var currentOrder = table.order()[0];
        var isAsc = currentOrder[1] === 'asc';

        // Toggle order between asc and desc for the S.No column
        table.order([
            [0, isAsc ? 'desc' : 'asc']
        ]).draw();
    });
}); // Set the initial ordering to descending based on the created_at column
    



$(document).on('click', '.delete', function() {
    var id = $(this).data('id');
    if (confirm('Are you sure you want to delete this item?')) {
        $.ajax({
            url: '{{ route("delete.item") }}',
            type: 'POST',
            data: {
                id: id,
                _token: '{{ csrf_token() }}'
            },
            success: function(response) {
                if (response.success) {
                    alert('Item deleted successfully.');
                    $('#constituency-datatable').DataTable().ajax.reload();  
                } else {
                    alert('Failed to delete item.');
                }
            },
            error: function(xhr, status, error) {
                alert('An error occurred.');
            }
        });
    }
});
$(document).on('click', '.edit', function() {
    var id = $(this).data('id');

    $.ajax({
        url: '/get-item/' + id,
        type: 'GET',
        success: function(data) {
            $('#edit-id').val(data.id);
            $('#description').val(data.description);
            $('#link').val(data.link);
            $('#status').val(data.status);

            // Set the constituency select options
            $('#constituency option').each(function() {
                if ($(this).val() == data.constituency_id) {
                    $(this).prop('selected', true);
                }
            });

            // Set the language select options
            $('#language_name option').each(function() {
                if ($(this).val() == data.language_id) {
                    $(this).prop('selected', true);
                }
            });

            $('#editModal').modal('show');
        },
        error: function(xhr) {
            console.error('Error fetching item data', xhr);
        }
    });
});



$('#editForm').submit(function(e) {
    e.preventDefault();
    var id = $('#edit-id').val();
    var formData = $(this).serialize();
    
    $.ajax({
        url: '/edit-item/' + id,
        type: 'PUT',
        data: formData,
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function(data) {
            $('#editModal').modal('hide');
            $('#successMessage').show().delay(3000).fadeOut(); // Show success message
            
            // Optionally refresh the DataTable or fetch the updated data
            location.reload();
        },
        error: function(xhr) {
            console.error('Error updating item', xhr.responseText);
            alert('An error occurred while updating the record.');
        }
    });
});



$(document).ready(function() {
    // Event handler for the click event on the "Cancel" button
    $('#editModal').on('click', '.btn-secondary', function() {
        // Find the modal and hide it
        $('#editModal').modal('hide');
    });
});


</script>
<script>
    setTimeout(function() {
        $('#successMessage').fadeOut('slow');
    }, 1000); // 10 seconds
</script>

  </body>
</html>