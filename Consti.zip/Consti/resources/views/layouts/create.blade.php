<!DOCTYPE html>
<html>
  <head> 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Constituency </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
   @include('admin.css')
   <style>
    /* select { width: 100%; } */
    .form-control {
    width: 100%; /* You can adjust this value as needed */
  }
    .required-field::after {
    content: ' *';
    color: red;
    .container{
        margin-top: 900px;
    }
}

.multiselect-dropdown {
    width: 100% !important;
    padding:5px 8px !important;
}
.same-width-input {
    width: 100% !;
    border: 2px solid black;
    box-sizing: border-box; /* Ensures padding and border are included in the width */
}
textarea{
  background: #E8F0FE !important;
}

</style>
  </head>
  <body>
  <form id="mainForm" method="post" action="{{ route('storeconstituency') }}" enctype="multipart/form-data">
   @include('admin.header')
    <div class="d-flex align-items-stretch">
      <!-- Sidebar Navigation-->
      @include('admin.sidebar') 
      <!-- Sidebar Navigation end-->
      <div class="page-content">
        <div class="page-header">
          <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">Create Constituency</h2>
          </div>
        </div>
        <div class="container">
          <div class="card mt-4">
            <!-- <div class="card-header">
              <h3 class="card-title">Create Constituency</h3>
            </div> -->
            <div class="card-body">
            <!-- @if (session('success')) -->
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong>Success</strong>  {{ session('success') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <!-- @endif -->
            @if (session('error'))
                <div class="alert alert-danger mt-3" role="alert">
                    {{ session('error') }}
                </div>
            @endif
<div class="container mt-5">
<form id="mainForm" action="{{ route('storeconstituency') }}" method="POST" enctype="multipart/form-data">
  @csrf
  <div class="mb-3">
    <label for="Constituency" class="form-label required-field">Constituency</label><br>
    <select name="constituency[]" id="field2" class="form-control same-width-input" multiple multiselect-search="true" multiselect-select-all="true" multiselect-max-items="5" required>
      <!-- <option value="">--select constituency--</option> -->
      @foreach($constituencies as $constituency)
      <option value="{{ $constituency->id }}">{{ $constituency->constituency }}</option>
      @endforeach
    </select>
</div>

<div class="mb-3">
    <label for="Language" class="form-label required-field">Language</label><br>
    <select name="language_id" id="language" class="form-control same-width-input" required>
      <option value="">--select language--</option>
      @foreach($languages as $language)
      <option value="{{ $language->id }}">{{ $language->name }}</option>
      @endforeach
    </select>
</div>


  <div class="mb-3">
    <label for="message" class="form-label required-field">Message</label>
    <textarea id="message" name="message" maxlength="255" onkeypress="return /^[0-9a-zA-Z\s]*$/i.test(event.key)" class="form-control" rows="4" required placeholder="Enter your message here" ></textarea>
  </div>

  <div class="mb-3">
    <label for="link" class="form-label">Link(optional)</label>
    <input type="url" id="link" name="link" class="form-control" maxlength="255">
  </div>

  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>
<script src="../js/multiselect-dropdown.js"></script>
<script>
    
    document.getElementById('mainForm').addEventListener('submit', function(event) {
        var selectedConstituencies = document.getElementById('field2').selectedOptions;
        
        // Check if at least one constituency is selected
        if (selectedConstituencies.length === 0) {
            alert('Please select at least one constituency.');
            event.preventDefault(); // Prevent form submission
        }
    });
</script>
<script>
  $(document).ready(function(){
 
    // Add the class 'multiselect-dropdown' to elements with the class 'form-control'
    $('.multiselect-dropdown').addClass('form-control');
  });
</script>

