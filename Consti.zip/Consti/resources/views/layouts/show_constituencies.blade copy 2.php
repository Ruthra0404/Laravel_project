@extends('layouts.app')

@section('main')
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.7.1/css/buttons.dataTables.min.css">

<div class="container mt-5">
    <h2 class="text-center">Constituencies</h2>
    <div class="row justify-content-center">
        <div class="col-md-12">
            <table id="constituency-datatable" class="table table-striped table-bordered table-hover">
                <thead>
                    <tr>
                        <!-- <th>S.No</th> -->
                        <th>Constituency</th>
                        <th>Language</th>
                        <th>Description</th>
                        <th>Link</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
</div>
<div id="editModal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form id="editForm">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Details</h5>
                    <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button> -->
                </div>
                <div class="modal-body">
                    <input type="hidden" id="edit-id" name="id">
                    <div class="form-group">
                        <label for="constituency">Constituency</label>
                        <input type="text" class="form-control" id="constituency" name="constituency" required>
                    </div>
                    <div class="form-group">
                        <label for="language_name">Language</label>
                        <input type="text" class="form-control" id="language_name" name="language_name" required>
                    </div>
                    <div class="form-group">
                        <label for="description">Description</label>
                        <input type="text" class="form-control" id="description" name="description" required>
                    </div>
                    <div class="form-group">
                        <label for="link">Link</label>
                        <input type="text" class="form-control" id="link" name="link" required>
                    </div>
                    <!-- <div class="form-group">
                        <label for="status">Status</label>
                        <input type="text" class="form-control" id="status" name="status" required>
                    </div> -->
                  
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>

<script type="text/javascript">
$(document).ready(function() {
    var table = $('#constituency-datatable').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: "{{ route('getConstituencies') }}",
        },
        columns: [
            { data: 'constituency', name: 'constituency' },
            { data: 'language_name', name: 'language_name' },
            { data: 'description', name: 'description' },
            { data: 'link', name: 'link' },
            {
                data: 'status',
                name: 'status',
                render: function(data, type, row) {
                    if (data == 'Y') {
                        return '<span style="color: green;">' + 'Active' + '</span>';
                    } else if (data == 'D') {
                        return '<span style="color: red;">' + 'Inactive' + '</span>';
                    } else {
                        return data;
                    }
                }
            },
            { data: 'created_at', name: 'created_at' },
            { data: 'action', name: 'action', orderable: false, searchable: false },
        ],
        dom: 'Bfrtip',
        buttons: [
            { extend: 'csv', text: 'CSV', className: 'btn btn-primary' },
            { extend: 'pdf', text: 'PDF', className: 'btn btn-success' },
            { extend: 'print', text: 'Print', className: 'btn btn-info' }
        ]
    });
});

$(document).on('click', '.delete', function() {
    var id = $(this).data('id');
    if (confirm('Are you sure you want to delete this item?')) {
        $.ajax({
            url: '{{ route("delete.item") }}',
            type: 'POST',
            data: {
                id: id,
                _token: '{{ csrf_token() }}'
            },
            success: function(response) {
                if (response.success) {
                    alert('Item deleted successfully.');
                    $('#constituency-datatable').DataTable().ajax.reload();  
                } else {
                    alert('Failed to delete item.');
                }
            },
            error: function(xhr, status, error) {
                alert('An error occurred.');
            }
        });
    }
});
$(document).on('click', '.edit', function() {
    var id = $(this).data('id');

    $.ajax({
        url: '/get-item/' + id, // Ensure this URL matches your route
        type: 'GET',
        success: function(data) {
            console.log(data); // This will help you see the response
            $('#edit-id').val(data.id);
            $('#description').val(data.description);
            $('#link').val(data.link);
            $('#status').val(data.status);
            $('#constituency').val(data.constituency);
            $('#language_name').val(data.language_name);
            $('#editModal').modal('show');
        },
        error: function(xhr) {
            console.error('Error fetching item data', xhr);
        }
    });
});

$('#editForm').submit(function(e) {
    e.preventDefault();
    var id = $('#edit-id').val();
    var formData = $(this).serialize();
    $.ajax({
        url: '/edit-item/' + id, // Ensure this URL matches your route
        type: 'PUT',
        data: formData,
        success: function(data) {
            $('#editModal').modal('hide');
            location.reload();
        },
        error: function(xhr) {
            console.error('Error updating item', xhr);
            alert('An error occurred while updating the record.');
        }
    });
});

</script>



@endsection