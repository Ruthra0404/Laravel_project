@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Edit Item</h1>
    <form action="{{ route('update.item', $storeConstituency->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="form-group">
            <label for="description">Description</label>
            <input type="text" class="form-control" id="description" name="description" value="{{ $storeConstituency->description }}" required>
        </div>
        <div class="form-group">
            <label for="link">Link</label>
            <input type="text" class="form-control" id="link" name="link" value="{{ $storeConstituency->link }}" required>
        </div>
        <div class="form-group">
            <label for="status">Status</label>
            <input type="text" class="form-control" id="status" name="status" value="{{ $storeConstituency->status }}" required>
        </div>
        <div class="form-group">
            <label for="constituency">Constituency</label>
            <input type="text" class="form-control" id="constituency" name="constituency" value="{{ $masterConstituency->constituency }}" required>
        </div>
        <div class="form-group">
            <label for="language_name">Language</label>
            <input type="text" class="form-control" id="language_name" name="language_name" value="{{ $language->name }}" required>
        </div>
        <button type="submit" class="btn btn-primary">Save changes</button>
    </form>
</div>
@endsection
