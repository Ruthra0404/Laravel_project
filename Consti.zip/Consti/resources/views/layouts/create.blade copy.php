@extends('layouts.app')

@section('main')
@include('admin.css')
@include('admin.header')
@include('admin.sidebar')
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">

<style>
    select { width: 100%; }
    .required-field::after {
    content: ' *';
    color: red;
    .container{
        margin-top: 900px;
    }
}

</style>
<body>
<div class="container mt-5">
    <form id="mainForm" action="{{ route('storeconstituency') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="mb-3">
            <label for="Constituency" class="form-label required-field ">Constituency</label><br>
            <select name="constituency[]" id="field2" multiple multiselect-search="true" multiselect-select-all="true" multiselect-max-items="3">
                @foreach($constituencies as $constituency)
                    <option value="{{ $constituency->id }}">{{ $constituency->constituency }}</option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label for="Language" class="form-label required-field">Language</label><br>
            <select name="language_id" id="language" class="form-select" required>
                <option value=""></option>
                @foreach($languages as $language)
                    <option value="{{ $language->id }}">{{ $language->name }}</option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label for="message" class="form-label required-field">Message</label>
            <textarea id="message" name="message" class="form-control" rows="4" required></textarea>
        </div>

        <div class="mb-3">
            <label for="link" class="form-label">Link(optional)</label>
            <input type="url" id="link" name="link" class="form-control">
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
</body>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>
<script src="../js/multiselect-dropdown.js"></script>
<script>
    document.getElementById('mainForm').addEventListener('submit', function(event) {
        var selectedConstituencies = document.getElementById('field2').selectedOptions;
        
        // Check if at least one constituency is selected
        if (selectedConstituencies.length === 0) {
            alert('Please select at least one constituency.');
            event.preventDefault(); // Prevent form submission
        }
    });
</script>
@endsection
