<style>
  li.active a {
    font-weight: bold;
    color: red; /* Customize as needed */
}
 </style>

<nav id="sidebar">
        <!-- Sidebar Header-->
        <div class="sidebar-header d-flex align-items-center">
          <div class="avatar"><i class="bi bi-person" style="font-size: 43px;"></i>
</div>
          <div class="title">
          @auth
        @if ((Auth::user()->name != ''))
        
            <h1 class="h5">{{ Auth::user()->name }}</h1>
            <!-- <p>Web Designer</p> -->
        @else
        
            <!-- <script>window.location = "{{ route('/home') }}";</script> --> 
            <a href="{{ route('/home') }}"> </a>

        @endif
    @endauth
          </div>

        
        </div>
        <!-- Sidebar Navidation Menus-->
        <span class="heading">Main</span>
<ul class="list-unstyled">
    <li class="{{ request()->routeIs('index') ? 'active' : '' }}">
        <a href="{{ route('index') }}"> <i class="icon-home"></i>Home </a>
    </li>
    <li class="{{ request()->routeIs('create') ? 'active' : '' }}">
        <a href="{{ route('create') }}"> <i class="bi bi-plus-circle"></i> Create </a>
    </li>
    <li class="{{ request()->routeIs('show_constituencies') ? 'active' : '' }}">
        <a href="{{ route('show_constituencies') }}"> <i class="icon-grid"></i>List </a>
    </li>
</ul>

             
               
      </nav>