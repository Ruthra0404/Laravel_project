
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Constituency - Admin Login</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap">
    <style>
        body {
            background-image: url('../images/background.png');
            background-size: cover;
            background-position: center;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-form {
            background: linear-gradient(45deg, #ff9933 33.33%, white 33.33% 66.67%, #138808 66.67%);
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
            text-align: flex;
            margin-left:1400px;
            margin-bottom:500px;
        }
        .form-group {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="login-form">
        <h2>Admin Login</h2>
        <form method="post" action="{{ route('login') }}">
            @csrf
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" onkeypress="return /[0-9a-zA-Z]/i.test(event.key)" required class="form-control">
                @error('username')
                    <div class="alert alert-danger mt-1">{{ $message }}</div>
                @enderror
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <div class="input-group">
                    <input type="password" id="password" name="password" required class="form-control">
                    <div class="input-group-append">
                        <button type="button" class="btn btn-primary" id="toggle-password">
                            <i class="fas fa-eye-slash"></i>
                        </button>
                    </div>
                </div>
                @error('password')
                    <div class="alert alert-danger mt-1">{{ $message }}</div>
                @enderror
            </div>
            @if (session('error'))
            <div class="alert alert-danger small" role="alert">
                {{ session('error') }}
            </div>
        @endif
        @if ($errors->has('auth_error'))
            <div class="alert alert-danger small">
                {{ $errors->first('auth_error') }}
            </div>
        @endif
            <button type="submit" class="btn btn-primary btn-login">Login</button>
        </form>
       
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#toggle-password').on('click', function() {
                var passwordInput = document.getElementById('password');
                if (passwordInput.type === 'password') {
                    passwordInput.type = 'text';
                    $(this).html('<i class="fas fa-eye"></i>');
                } else {
                    passwordInput.type = 'password';
                    $(this).html('<i class="fas fa-eye-slash"></i>');
                }
            });
        });
    </script>

