<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class UpdateStoreConstituencyTableMakeLinkNullable extends Migration
{
    public function up()
    {
        Schema::table('store_constituency', function (Blueprint $table) {
            $table->string('link')->nullable()->change();
        });
    }

    public function down()
    {
        Schema::table('store_constituency', function (Blueprint $table) {
            $table->string('link')->nullable(false)->change();
        });
    }
}

