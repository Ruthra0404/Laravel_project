<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMasterLanguageTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {Schema::create('languages', function (Blueprint $table) {
        $table->id();
    $table->string('name', 255)->charset('utf8mb4')->collation('utf8mb4_general_ci');
    $table->string('code', 2)->charset('utf8mb4')->collation('utf8mb4_general_ci')->unique();
    $table->string('status', 255)->charset('utf8mb4')->collation('utf8mb4_general_ci')->default('active');
    $table->timestamps();
    });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('master_language');
    }
}
